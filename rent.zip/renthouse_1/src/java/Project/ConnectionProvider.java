/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Project;

/**
 *
 * @author vinaybs
 */
import java.sql.*;
public class ConnectionProvider {
    public static Connection getCon()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/rent","root","savepassword");
            return con;
        }
        catch(ClassNotFoundException | SQLException e)
           
        {
            System.out.print(e);
            return null;
        }
    }
    
}


